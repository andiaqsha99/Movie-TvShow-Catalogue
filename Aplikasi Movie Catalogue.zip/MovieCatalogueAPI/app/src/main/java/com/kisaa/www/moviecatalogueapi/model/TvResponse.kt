package com.kisaa.www.moviecatalogueapi.model

data class TvResponse(
    var results: List<TvShows>? = null
)