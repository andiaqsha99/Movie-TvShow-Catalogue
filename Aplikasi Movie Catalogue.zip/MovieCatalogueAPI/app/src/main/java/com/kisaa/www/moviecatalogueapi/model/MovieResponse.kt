package com.kisaa.www.moviecatalogueapi.model

data class MovieResponse(
    var results: List<Movies>? = null
)